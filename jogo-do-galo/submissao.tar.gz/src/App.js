import logo from './logo.svg';
import './App.css';
import { JogoDoGalo } from './JogoDoGalo';

function App() {
  return (
    <div className="App">
    
      <JogoDoGalo />
    </div>
  );
}

export default App;
