import { useState } from "react";
import { adicionarJogada, verificarFimDoJogo, verificarVencedor } from "./jogoDoGaloLogic";

const JOGOINICIAL = {
    tabuleiro: [
        ["", "", ""],
        ["", "", ""],
        ["", "", ""],
    ],
    jogadorAtual: 'X'
}

export function JogoDoGalo() {
    const [jogo, setJogo] = useState(JOGO_INICIAL)
    const reiniciaJogo = () => setJogo(JOGO_INICIAL)
    const trataClique = (linha, coluna) =>
        setJogo(j => adicionarJogada(j, linha, coluna))
    const jogoTerminado = verificarFimDoJogo(jogo)
    const jogadorAtual = jogo.jogadorAtual
    const vencedor = verificarVencedor(jogo)

    return (
        <div>
            <h1>Jogo do Galo</h1>
            <table className="jogo-do-galo">
                <tbody>
                    {
                        jogo.tabuleiro.map((l, i) => (
                            <tr key={i}>
                                {
                                    l.map((c, j) => (
                                        <td
                                            onClick={() => trataClique(i, j)}
                                            data-testid={l${i}c${j}}
                                            key={j}>
                                            {c === "_" ? "" : c}
                                        </td>
                                    ))
                                }
                            </tr>
                        ))
                    }
                </tbody>
            </table>
            {
                !jogoTerminado && (
                    <div>
                        Jogador Atual: <span data-testid="turn">{jogadorAtual}</span>
                    </div>
                )
            }
            {
                jogoTerminado && (
                    <div data-testid="gameover">
                        Jogo Terminado!
                    </div>
                )
            }
            {
                vencedor && (
                    <div>
                        Vencedor: <span data-testid="winner">{vencedor}</span>
                    </div>
                )
            }
            <button
                data-testid="restart"
                onClick={reiniciaJogo}>
                Reiniciar
            </button>

        </div>
    )
}